#ifndef SLEEPTIMER_HPP_INCLUDED
#define SLEEPTIMER_HPP_INCLUDED

/* Sleep Timer */
using namespace std;
using namespace std::this_thread; // sleep_for, sleep_until
using namespace std::chrono; // nanoseconds, system_clock, seconds

#endif // SLEEPTIMER_HPP_INCLUDED
