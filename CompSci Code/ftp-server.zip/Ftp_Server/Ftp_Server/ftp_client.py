import socket
import threading
import os
import sys

ftp_client_default_port = 18964

class client_data_thread(threading.Thread):
    def __init__(self, command, file_name):
        self.dataPort = 18963
        self.sock = socket.socket()
        self.sock.bind(("localhost", self.dataPort))
        self.sock.listen(1)
        self.sock.settimeout(1)
        self.command = command
        self.file_name = file_name
        self.current_dir = os.path.abspath("./ftp-downloads/")
        threading.Thread.__init__(self)

    def run(self):
        try:
            self.client_data, address = self.sock.accept()
        except:
            return
        if self.command == "list":
            self.list()
        elif self.command == "retr":
            self.retr()
        elif self.command == "stor":
            self.stor()
        else:
            print("Unknown command")

    def list(self):
        print("Recieving list of files")
        recieved_files = ""
        data = str(self.client_data.recv(1024), "utf-8")
        while data:
            recieved_files += data
            data = str(self.client_data.recv(1024), "utf-8")
            print("File List:\n")
            print(recieved_files + "\n")
            self.client_data.close()

    def retr(self):
        open_file = open(os.path.join(self.current_dir, self.file_name), "wb+")
        print("Retrieving file")
        try:
            data = self.client_data.recv(1024)
            while data:
                open_file.write(data)
                data = self.client_data.recv(1024)
        except:
            print("Error retrieving data")
            return
        open_file.close()
        print("File retrieved")
        self.client_data.close()

    def stor(self):
        try:
            open_file = open(os.path.join(self.current_dir, self.file_name), "rb+")
            print("Storing to file")
        except:
            print("File not found")
            self.client_data.close()
            return
        while True:
            self.data = open_file.read(8)
            if not self.data: break
            self.client_data.sendall(self.data)
        open_file.close()
        return

class response_thread(threading.Thread):
  def __init__(self, conn):
    self.conn = conn
    threading.Thread.__init__(self)

  def run(self):
    while True:
      self.client_response()

  def client_response(self):
    try:
      response = str(self.conn.recv(1024), "utf-8")
      print(response)
    except:
      return

class ftp_client:
    def __init__(self):
        self.client_socket = socket.socket()
        self.client_socket.settimeout(2)
        self.current_dir = os.path.abspath("./ftp-downloads/")
        if not os.path.exists(self.current_dir):
            os.makedirs(self.current_dir)
        while True:
            print("Enter command: ")
            user_input = input().lower().split(" ")
            if user_input[0] == "connect":
                self.connect(user_input)
            elif user_input[0] == "list":
                self.list(user_input)
            elif user_input[0] == "retr":
                self.retr(user_input)
            elif user_input[0] == "stor":
                self.stor(user_input)
            elif user_input[0] == "quit":
                self.quit(user_input)
            else:
                print("Unknown command")
            try:
                self.response_thread.client_response()
            except:
                continue


    def connect(self, user_input):
        if len(user_input) != 3:
            print("Not a valid connection input")
            print("try: connect localhost: 18964")
            user_input = ["connect", "localhost", 7711]
        try:
            client_port = int(user_input[2])
            print(user_input[1])
        except ValueError:
            print("Invalid port number")
            return
        try:
            self.client_socket.connect((user_input[1], client_port))
            self.response_thread = response_thread(self.client_socket)
            self.response_thread.setDaemon(True)
            self.response_thread.start()

        except ConnectionRefusedError:
            print("Connection refused - check port number")
            return
        except OSError:
            print("Connect request was made on an already connected socket or the server is not listening on that port.")
            return

        print("Connection established on port {}."+ user_input[2])

    def list(self, user_input):
        if len(user_input) != 1:
            print("Invalid command for list")
            return
        try:
            self.send("LIST")
        except:
            print("Connect to a server before using list command")
            return
        self.client_recieve_data(command="list")

    def retr(self, user_input):
        if len(user_input) != 2:
            print("Invalid command for retr")
            return
        try:
            self.send("RETR " + user_input[1])
        except:
            print("Connect to a server before using retr command")
            return
        self.client_recieve_data(command="retr", file_name=user_input[1])

    def stor(self, user_input):
        if len(user_input) != 2:
            print("Invalid command for store")
            return
        try:
            self.send("STOR " + user_input[1])
        except:
            print("Connect to a server before using store command")
            return
        self.client_recieve_data(command="stor", file_name=user_input[1])

    def quit(self, user_input):
        if len(user_input) != 1:
            print("Invalid command for quit")
            return
        else:
            try:
                self.send("QUIT")
            except:
                exit()
        exit()

    def send(self, message, encoding="utf-8"):
        self.client_socket.sendall(bytearray(message + "\r\n", encoding))

    def client_recieve_data(self, command, file_name=""):
        try:
            cdt = client_data_thread(command=command, file_name=file_name)
            cdt.start()
            cdt.join()
        except:
            print("Error in client recieve data")
            print("Unexpected error: ", sys.exc_info()[0])
            print("Unexpected error: ", sys.exc_info()[1])
            print("Unexpected error: ", sys.exc_info()[2])
            exit()


if __name__ == '__main__':
    client = ftp_client()
