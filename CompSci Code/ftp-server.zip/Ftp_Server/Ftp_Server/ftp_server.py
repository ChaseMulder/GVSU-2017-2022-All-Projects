import socket
import threading
import os
import sys
import os.path

server_port = 18964
data_port = server_port - 1
ftp_client_default_port = 18963
send_server_response_thread = ""

class server_data_thread(threading.Thread):
    def __init__(self, socket, cmd, data, filename=""):
        self.server_socket = socket
        self.cmd = cmd
        self.data = data
        self.filename = filename
        threading.Thread.__init__(self)

    def run(self):
        if self.cmd == "list":
            self.list()
        elif self.cmd == "retr":
            self.retr()
        elif self.cmd == "stor":
            self.stor(self.filename)
        else:
            print('unknown command')

    def list(self):
        global data_thread_status
        try:
            self.server_socket.connect(("localhost", 18963))
            self.server_socket.sendall(bytearray(self.data, "utf-8"))
            self.server_socket.close()
            data_thread_status = "Closing data connection"
        except:
            data_thread_status = "Can't open data connection"

    def retr(self):
        global data_thread_status
        try:
            self.server_socket.connect(("localhost", 18963))
            self.server_socket.sendall(bytearray(self.data))
            self.server_socket.close()
            data_thread_status = "Closing data connection"
        except:
             data_thread_status = "Can't open data connection"

    def stor(self, filename):
        global data_thread_status
        try:
            self.server_socket.connect(("localhost", 18963))
        except:
            data_thread_status = "Can't open connection"
        try:
            data = self.server_socket.recv(1024)
            if data:
                file = open(filename, "wb")
                print(filename)
                while True:
                    if not data:
                      break
                    print(data)
                    file.write(data)
                    data = self.server_socket.recv(1024)
                file.close()
                print("Closing connection")
        except:
            print("Error stor")
        self.server_socket.close()

class server_response_thread(threading.Thread):
    def __init__(self, socket):
        self.socket = socket
        self.current_dir = os.path.abspath("./ftp-files/")
        self.server_socket = None
        threading.Thread.__init__(self)
        self.finished_running = False

    def run(self):
        self.send_server_response("Awaiting input")
        while True:
            command = str(self.socket.recv(1024), "utf-8")
            print(command)
            command = command.rstrip("\r\n")
            split = command.lower().split(" ")
            print(split)
            getattr(self, split[0])(split)
            if self.finished_running:
                return

    def send_server_response(self, message, encoding="utf-8"):
        print("Server control response: " + message)
        self.socket.sendall(bytearray(message + "\r\n", encoding))

    def quit(self, commands):
        self.send_server_response("Closing connection")
        self.socket.close()
        self.finished_running = True

    def list(self, commands):
        self.current_dir
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        files_in_directory = os.listdir(self.current_dir)
        list_files = ""
        for files in files_in_directory:
            list_files = list_files + files + "\n"
        data = server_data_thread(socket=server_socket, cmd="list", data=list_files)
        self.send_server_response("Opening data connection")
        data.start()
        data.join()
        self.send_server_response("Data transfer over")

    def retr(self, commands):
        file_name = commands[1]
        print("Server recieved file name: " + file_name)
        file_name = os.path.join(self.current_dir, file_name)
        if os.path.exists(file_name):
            print("File exists")
            if os.access(file_name, os.R_OK):
                data = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                data_in_file = ""
                file = open(file_name, 'rb')
                data_in_file = file.read()
                data = server_data_thread(socket=data, cmd="retr", data=data_in_file)
                self.send_server_response("Opening data connection")
                print("Retrieving data")
                data.start()
                data.join()
                return
        else:
            self.send_server_response("File not found")
        return

    def stor(self, commands):
        file_name = commands[1]
        print("Server recieved file name: " + file_name)
        file_name = os.path.join(self.current_dir, file_name)
        if os.access(file_name, os.R_OK) or not os.path.isfile(file_name):
            data = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                data = server_data_thread(socket=data, cmd="stor", data="", filename=file_name)
                self.send_server_response("Opening data connection")
                print("Storing data")
                data.start()
                self.send_server_response("Data sent")
                data.join()
                return
                print("data sent")
                self.send_server_response("Data sent")
            except:
                self.send_server_response("file not in path")
        else:
            print("no file")
            return
        return


class ftp_server:
    def __init__(self):
        # self.port = 18964
        self.server_socket = socket.socket()
        self.server_socket.bind(("localhost", server_port))
        # Listen
        self.server_socket.listen()
        while True:
            try:
                print("Waiting for: connect on: " + self.server_socket.getsockname()[0] + ":" + str(
                    self.server_socket.getsockname()[1]))
                connection_socket, addr = self.server_socket.accept()

                print("Connection accepted")
                srt = server_response_thread(connection_socket)
                srt.start()
            except:
                print("Unexpected error: ", sys.exc_info()[0])
                print("Unexpected error: ", sys.exc_info()[1])
                print("Unexpected error: ", sys.exc_info()[2])
                self.server_socket.close()
                print("No connection, exiting")
                exit()


if __name__ == '__main__':
    server = ftp_server()
