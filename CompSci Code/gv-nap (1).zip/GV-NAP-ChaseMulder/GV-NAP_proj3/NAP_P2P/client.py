import os
import pickle
import threading
import socket
from threading import *
from ftp_Server import *

class peerServer:
    def __init__(self):
        print("Welcome To GV-NAP File Sharing System")
        self.file_name = ""
        self.peer_port = 0
        self.nameList = [0,0] #Can be expanded
        self.fileList = [0,0]
        self.count = 0


    def start_server(self):
        while True:
            choice = input("Menu \n(1) Register\n(2) Search\n(3) List all files\n(4) Download\n(5) Exit server\n")
            choice = int(choice)
            if choice == 1:
                peer_id = input("Enter a keyword: ")
                global glblList
                glblList = []
                glblList=[ord(ch) for ch in peer_id]
                #print(glblList)
                self.nameList[self.count] = peer_id
                #print(nameList)
                list2=0
                for ch in glblList:
                    list2+=ch
                #print(list2)
                self.file_name = input("Enter file name: ")
                self.fileList[self.count] = self.file_name
                self.count += 1
                self.peer_port = int(list2)
                self.register()
                start_sharing(self.peer_port, 'localhost')

            elif choice == 2:
                self.search()

            elif choice == 3:
                self.list_all()

            elif choice == 4:
                peer_id = input("Enter the peer id #: ")
                #print(list)
                file_name = input("Enter file name: ")
                self.download(int(peer_id), file_name)

            elif choice == 5:
                self.quit()
                break
            else:
                continue



    def register(self):
        client = socket.socket()
        client.connect(('localhost', 18964))
        register_data = [1, self.peer_port, self.file_name]
        data = pickle.dumps(register_data)
        client.send(data)
        state = client.recv(1024)
        print(state.decode('utf-8'))
        client.close()

    def quit(self):
        client = socket.socket()
        client.connect(('localhost', 18964))
        register_data = [5, self.peer_port, self.file_name]
        data = pickle.dumps(register_data)
        client.send(data)
        state = client.recv(1024)
        print(state.decode('utf-8'))
        client.close()


    def search(self):
        client = socket.socket()
        client.connect(('localhost', 18964))
        keyword = input("Enter a keyword: ")
        index = 0
        for index in range(self.count):
            #print(self.count)
            #print(keyword)
            #print(self.nameList[index])
            if keyword == self.nameList[index]:
                file_name = self.fileList[index]
                print("File Found!")
                break
                #print(file_name)
                #print(keyword)
            else:
                file_name = ""
            index+=1
        print("File found: " +file_name)
        register_data = [2, file_name]
        data = pickle.dumps(register_data)
        client.send(data)
        state = pickle.loads(client.recv(1024))
        self.print_list(state[0], state[1])
        client.close()

    def list_all(self):
        client = socket.socket()
        client.connect(('localhost', 18964))
        data = pickle.dumps([3])
        client.send(data)
        state = pickle.loads(client.recv(1024))
        self.print_list(state[0], state[1])
        client.close()

    def print_list(self, files, keys):
        if len(files) == 0:
            print("There is no file available")
        else:
            print("Peer ID    File Name    Date Added")
            for item in files:
                print(item[keys[0]],"  ",item[keys[1]], "    ", item[keys[2]])
                #print("Peer_id: ", item[keys[0]])
            print("------------------------------------")

    def download(self, peer_id, file_name):
        client = socket.socket()
        client.connect(('localhost', peer_id))
        list_data = [4, str(file_name)]
        data = pickle.dumps(list_data)
        client.send(data)

        file_path = os.path.join(os.getcwd(), 'File_Sharing_Server')
        file_path = os.path.join(file_path, 'Downloads')

        with open(os.path.join(file_path, file_name), 'wb') as myfile:
            while True:
                data = client.recv(1024)
                #print(data.decode("utf-8"))
                if not data:
                    myfile.close()
                    break
                myfile.write(data)
        client.close()
        print('\nFile is downloaded successfully.')


peer = peerServer()
peer.start_server()
