import os
import pickle
import threading
import socket
from threading import *


class ftp_Server(threading.Thread):
    def __init__(self, port, host, max_connection):
        threading.Thread.__init__(self)
        self.host = host
        self.semaphore = Semaphore(max_connection)
        self.port = port
        self.client = socket.socket()
        self.client.bind((self.host, self.port))
        self.client.listen(max_connection)

    def run(self):
        print("Client is ready to share the files")
        while True:
            client, addr = self.client.accept()
            print("Got connection from", addr[0], " port at", addr[1])
            request = pickle.loads(client.recv(1024))
            if request[0] == 4:
                file_path = os.path.join(os.getcwd(), 'File_Sharing_Server')
                file_path = os.path.join(file_path, 'Uploads')
                file_name = request[1]
                full_path = os.path.join(file_path, file_name)
                self.semaphore.acquire()

                with open(full_path, "rb") as myfile:
                    while True:
                        rd = myfile.read(1024)
                        while rd:
                            client.send(rd)
                            rd = myfile.read(1024)
                        myfile.close()
                        client.close()
                        break
                self.semaphore.release()
                print('File Sent Successfully', end = '')
            else:
                continue


def start_sharing(port, host):
    peer = ftp_Server(port, host, 2)
    peer.start()
