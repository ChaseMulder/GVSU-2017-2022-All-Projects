import socket
import threading
import base64
import json
import os
import contextlib
import datetime
import time
import os.path

timestamp = time.time()
timestamp = time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(timestamp))
##timestamp = "Wed, 15 Feb 2010 19:43:31 GMT"
print(timestamp)



image_file = 'image.png'
api = 'http://localhost:18964/image.png'

def recieve_HTTP(connection_socket):
    ##Recieve HTML
    sentence = connection_socket.recv(buffer_size).decode('utf-8')
    s1 = (sentence.split('/'))
    s2 = (sentence.split(' '))
    s3 = (sentence.split('.'))
    s4 = s3[1].split(' ')
    print(sentence)
    var1 = 0
    var2 = 0
    if "If-Modified-Since" in sentence:
     s5 = sentence.split(':')
     print(s5)
     print(s5[17]) ##if modified since 
     s6 = s5[18].split(' ')
     ##print(s6) ##day
     print(s6[5]) ##day
     print(s5[19]) ##hour
     timestamp2 = timestamp.split(':')
     timestamp3 = timestamp.split(' ')
     t4 = timestamp2[0].split(' ')
     print(t4[4]) ##day
     print(timestamp2[1]) ##hour
     var1 = t4[4] == s6[5]
     var2 = int(s5[19]) == int(timestamp2[1])
     print(var1)
     print(var2)

    if var1 & var2:
        print("304")
        response = 'HTTP/1.1 304 Not Modified\r\n\r\n'
        connection_socket.send(response.encode('utf-8'))
        connection_socket.close()

    if os.path.exists('.' + s2[1]):
       if s4[0] == "html":  
           ##Send text Response
           response = 'HTTP/1.0 200 OK\r\n'
           response1 = 'Content-Type: text/html\r\n'
           response3 = 'Last-Modified:' + timestamp + '\r\n\r\n'
           response2 = '<html><h1>Hello world!</h1>Welcome to my <i>amazing</i> web server!</html>\r\n'
           connection_socket.send(response.encode('utf-8'))
           connection_socket.send(response1.encode('utf-8'))
           connection_socket.send(response3.encode('utf-8'))
           connection_socket.send(response2.encode('utf-8'))
           connection_socket.close()
    if os.path.exists('.' + s2[1]):
        if s4[0] == "png":
            ##Send image Response
            with open(image_file, "rb") as f:
                im_bytes = f.read()        
                response = im_bytes           
                response1 = 'HTTP/1.0 200 OK\r\n'
                response2 = 'Content-Type: image/png\r\n\r\n'
                connection_socket.send(response1.encode('utf-8'))
                connection_socket.send(response2.encode('utf-8'))
                connection_socket.send(response)
                connection_socket.close()
    else:
        print("404")
        response = 'HTTP/1.1 404 Not Found\r\n'
        response1 = 'Content-Type: text/html\r\n\r\n'
        response2 = '<html><h1>404 error: File not found</h1>The URL you requested:  <i>' + s2[1] + '</i> was not found:(</html>\r\n'
        connection_socket.send(response.encode('utf-8'))
        connection_socket.send(response1.encode('utf-8'))
        connection_socket.send(response2.encode('utf-8'))
        connection_socket.close()

server_ip = 'localhost'
server_port = 18964
buffer_size = 1024
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((server_ip, server_port))
##Listen
server_socket.listen()
print('The server is ready to receive')
while True:
    ##Create Connection
    connection_socket, addr = server_socket.accept()
    threading.Thread(target=recieve_HTTP, args=(connection_socket,)).start()